import './globals.css';
import { Providers } from '@/components/shared/providers';

export const metadata = {
    title: 'CVSKJ - Sales & Distribution',
    description: 'Management System for CVSKJ',
};

export default function RootLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return (
        <html lang="en">
            <body className="antialiased">
                <Providers>
                    {children}
                </Providers>
            </body>
        </html>
    );
}
